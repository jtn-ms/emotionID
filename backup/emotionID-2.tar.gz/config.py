import os

#RGB ? GRAY
CHANNEL_SIZE = 1

# WebCam Config
IMAGE_SIZE = 39

# Facial LandMark
FACE_CASCADE_XML = './landmark/haarcascade_frontalface_alt.xml'
LANDMARK_SIZE = 5
LANDMARK_PREDICTOR = './shape_predictor_68_face_landmarks.dat'


