#import Tkinter as tk
try:
    from Tkinter import *
except ImportError:
    from tkinter import *

import cv2
from PIL import Image, ImageTk

#Maximize the Screen
class FullScreenApp(object):
    def __init__(self, master, **kwargs):
        self.master=master
        pad=3
        self._geom='200x200+0+0'
        master.geometry("{0}x{1}+0+0".format(
            master.winfo_screenwidth()-pad, master.winfo_screenheight()-pad))
        master.bind('<Escape>',self.toggle_geom)            
    def toggle_geom(self,event):
        geom=self.master.winfo_geometry()
        print(geom,self._geom)
        self.master.geometry(self._geom)
        self._geom=geom

width, height = 800, 600
cap = cv2.VideoCapture(0)
#cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
#cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)

root = Tk()
#Show Input Frame
root.bind('<Escape>', lambda e: root.quit())
lmain = Label(root)
lmain.pack()

def show_frame():
    _, frame = cap.read()
    frame = cv2.flip(frame, 1)
    cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
    img = Image.fromarray(cv2image)
    imgtk = ImageTk.PhotoImage(image=img)
    lmain.imgtk = imgtk
    lmain.configure(image=imgtk)
    lmain.after(10, show_frame)

#ChatBox
input_user = StringVar()
input_field = Entry(root,text=input_user)
input_field.pack()

def Enter_pressed(event):
    """Took the current string the Entry Field."""
    input_get = input_field.get()
    input_field.delete(0,'end')
    print(input_get)
frame = Frame(root,width=100,height=100)
input_field.bind("<Return>",Enter_pressed)
frame.pack()

show_frame()
app = FullScreenApp(root)
root.mainloop()
