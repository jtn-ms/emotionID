#import Tkinter as tk
import os
try:
    from Tkinter import *
except ImportError:
    from tkinter import *

import cv2
from PIL import Image, ImageTk

#webcam + save video parameter
global cap
cap = cv2.VideoCapture(0)
global width,height
width, height = 640, 480
global fps
fps=20
global fourcc
fourcc = cv2.cv.CV_FOURCC('D','I','V','X')
global writer
writer = cv2.VideoWriter('record.AVI',	fourcc, fps, (width,height), 1)
#questions
global questions
questions = [ 	'Remember when you were happiest ever',
		'Remember when you fell in love with someone for the first time',
		'Remember when you broke up with your best friend'
		]
#Maximize the Screen
class FullScreenApp(object):
    def __init__(self, master, **kwargs):
        self.master=master
        pad=3
        self._geom='200x200+0+0'
        master.geometry("{0}x{1}+0+0".format(
            master.winfo_screenwidth()-pad, master.winfo_screenheight()-pad))
        master.bind('<Escape>',self.toggle_geom)
	master.bind('<Escape>', lambda e: master.quit())
	#space between button and picture
	self.margin = Frame(self.master,width=100,height=100)
	self.margin.pack()
	#text label
       	self.entry = Entry(self.master,text='Q & A',width=100)
	self.entry.focus()
	self.entry.bind("<Return>",self.Enter_pressed)
	self.entry.pack()
	#clear button
	self.clear_button = Button(self.master,text="Clear", command=self.clear_text)
	self.clear_button.pack(side=LEFT)

	#next button
	self.question_number = 0
	self.image_number = 0
	self.next_button = Button(self.master,text="Next", command=self.next_question)
	self.next_button.pack(side=RIGHT)
	###make dir
	os.mkdir('./out/' + str(self.question_number))

	#space between button and picture
	self.frame = Frame(self.master,width=100,height=50)
	self.frame.pack()
	#show input frame
        self.lmain = Label(self.master)
	self.lmain.pack()
	self.show_frame()

    def insert_text(self,question):
	self.clear_text()
	self.entry.insert(0,question)

    def clear_text(self):
  	self.entry.delete(0,'end')

    def next_question(self):
  	self.insert_text(questions[self.question_number])
	self.question_number += 1
	self.image_number = 0
	#make dir
	os.mkdir('./out/' + str(self.question_number))

    def Enter_pressed(self,event):
        """Took the current string the Entry Field."""
        response = self.entry.get()
        self.clear_text()
        print(response)
	return response

    def show_frame(self):
	ch = cv2.waitKey(1000 / fps)
	if ch == 27:
	   return
    	_, frame = cap.read()
    	frame = cv2.flip(frame, 1)
	frame = cv2.resize(frame, (width,height))
    		
	##save video
	writer.write(frame)
	##save image
	cv2.imwrite('./out/' + str(self.question_number) + '/' + str(self.image_number) +'.png',frame)
	self.image_number += 1	
	#Red mark
	cv2.circle(frame, (width/2,height/5), 50, (0,0,255),3)
	cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
	
    	img = Image.fromarray(cv2image)
    	imgtk = ImageTk.PhotoImage(image=img)
    	self.lmain.imgtk = imgtk
    	self.lmain.configure(image=imgtk)
    	self.lmain.after(10, self.show_frame)
	           
    def toggle_geom(self,event):
        geom=self.master.winfo_geometry()
        print(geom,self._geom)
        self.master.geometry(self._geom)
        self._geom=geom

if __name__ == '__main__':
    root = Tk()
    app = FullScreenApp(root)
    root.mainloop()
