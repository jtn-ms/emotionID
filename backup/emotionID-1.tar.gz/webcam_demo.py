import numpy as np
import matplotlib.pyplot as plt
import os.path
import scipy
import argparse
import math
import sys
sys.path.append('/usr/local/lib/python2.7/site-packages')
import cv2
import time
try:
    from Tkinter import *
except ImportError:
    from tkinter import *

window = Tk()

input_user = StringVar()
input_field = Entry(window,text=input_user)
input_field.pack()

def Enter_pressed(event):
    """Took the current string the Entry Field."""
    input_get = input_field.get()
    print(input_get)
frame = Frame(window,width=100,height=100)
input_field.bind("<Return>",Enter_pressed)
frame.pack()

window.mainloop()

cv2.namedWindow("Input")
#cv2.namedWindow("Output")

cap = cv2.VideoCapture(0) # Change this to your webcam ID, or file name for your video file

rval = True
framecount=0
while rval:
	start = time.time()
	rval, frame = cap.read()

        if rval == False:
            break

	end = time.time()
	#print '%30s' % 'Grabbed camera frame in ', str((end - start)*1000), 'ms'

	start = time.time()
	frame = cv2.resize(frame, (320,240))
	input_image = frame.transpose((2,0,1))
	# input_image = input_image[(2,1,0),:,:] # May be required, if you do not open your data with opencv
	input_image = np.asarray([input_image])
	end = time.time()
	#print '%30s' % 'Resized image in ', str((end - start)*1000), 'ms'

	start = time.time()
	#do something
	end = time.time()
	#print '%30s' % 'Executed SegNet in ', str((end - start)*1000), 'ms'

	#print '%30s' % 'Processed results in ', str((end - start)*1000), 'ms\n'

	cv2.imshow("Input", frame)
	#cv2.imshow("Output", out)
	
	if framecount == 0:
	   cv2.imwrite('/media/frank/Data/Test/emotionID/save.png',frame)
	   framecount = 1
	
	key = cv2.waitKey(1)
	if key == 27: # exit on ESC
	    break
cap.release()
cv2.destroyAllWindows()

