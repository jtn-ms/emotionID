#import Tkinter as tk
try:
    from Tkinter import *
except ImportError:
    from tkinter import *

import cv2
from PIL import Image, ImageTk

global cap
cap = cap = cv2.VideoCapture(0)

#Maximize the Screen
class FullScreenApp(object):
    def __init__(self, master, **kwargs):
        self.master=master
        pad=3
        self._geom='200x200+0+0'
        master.geometry("{0}x{1}+0+0".format(
            master.winfo_screenwidth()-pad, master.winfo_screenheight()-pad))
        master.bind('<Escape>',self.toggle_geom)
	master.bind('<Escape>', lambda e: master.quit())
	self.lmain = Label(master)
	self.lmain.pack() 
	self.show_frame()

    def show_frame(self):
	width, height = 800, 600
	#cap = cv2.VideoCapture(0)
	_, frame = cap.read()
	frame = cv2.flip(frame, 1)
	cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
	img = Image.fromarray(cv2image)
	imgtk = ImageTk.PhotoImage(image=img)
	self.lmain.imgtk = imgtk
	self.lmain.configure(image=imgtk)
	self.lmain.after(10, self.show_frame)

    def toggle_geom(self,event):
        geom=self.master.winfo_geometry()
        print(geom,self._geom)
        self.master.geometry(self._geom)
        self._geom=geom

root = Tk()
app = FullScreenApp(root)
root.mainloop()
