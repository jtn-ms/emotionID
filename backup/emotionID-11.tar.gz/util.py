import numpy as np
import random
import Image
import os
import re
import cv2
import config as cfg
import math

#Matrix to Vector
def arr2vec(arr,filename = None):
    size = 1
    for i in range(len(arr.shape)):
	size *= arr.shape[i]  	
    vec = arr.reshape((size,))
    if  filename is not None:
	arr.tofile(filename + '.vec')	
    return vec

#draw line
def drawLine(img,shape,here,there,isClosed=False,linewidth=2):
    for i in range(here,there):
    	cv2.line(img,(shape[i][0],shape[i][1]),(shape[i + 1][0],shape[i + 1][1]),255,linewidth)		
    if  isClosed:
     	cv2.line(img,(shape[here][0],shape[here][1]),(shape[there][0],shape[there][1]),255,linewidth)

#draw contour
def drawContours(img,coords,linewidth=2):
    drawLine(img,coords,0,16)
    drawLine(img,coords,17,21)
    drawLine(img,coords,22,26)
    drawLine(img,coords,27,30)
    drawLine(img,coords,30,35,True)
    drawLine(img,coords,36,41,True)
    drawLine(img,coords,42,47,True)
    drawLine(img,coords,48,59,True)
    drawLine(img,coords,60,67,True)
    cv2.line(img,(coords[48][0],coords[48][1]),(coords[60][0],coords[60][1]),255,linewidth)
    cv2.line(img,(coords[54][0],coords[54][1]),(coords[64][0],coords[64][1]),255,linewidth)

#Array to Image
def arr2img(arr, filename = None):
    #data is 1 or -1 matrix
    if  len(arr.shape) == 1:
	dim = int(math.sqrt(len(arr)))
	arr = arr.reshape((dim,dim))
    img = np.zeros(arr.shape, np.uint8)
    img[arr==1] = 255
    img[arr==-1] = 0
    if filename is not None:
        cv2.imwrite(filename + '.png',img)
    return img

#Image to Array
def img2arr(img, filename = None):
    #
    arr = np.ones((img.shape),np.int)
    arr[:] = -1
    arr[img > 128] = 1
    if  filename is not None:
	arr.tofile(filename + '.dat')
    return arr

#facial landmarks to feature space(array)
def fpoints2array(points, filename = None, newdim = cfg.DIM):
    # INT2FLOAT
    points = points.astype(float)
    #
    MAX = np.amax(points, axis=0)
    MIN = np.amin(points, axis=0)
    width = MAX.item(0) - MIN.item(0)
    height = MAX.item(1) - MIN.item(1)
    # MOVE
    points -= [MIN[0],MIN[1]]
    # RESIZE
    x_ratio = newdim / width
    y_ratio = newdim / height
    points *= [x_ratio,y_ratio]
    # FLOAT2INT
    points = np.ceil(points)
    points = points.astype(int)
    points[points == newdim] = newdim - 1
    # POINT2IMG
    img = np.zeros((newdim, newdim), np.uint8)
    drawContours(img,points) 
    if  filename is not None:
    	cv2.imwrite(filename + '.png',img)
	cv2.imshow('test',img)
	cv2.waitKey(1)
    # IMG2ARR
    arr = img2arr(img,filename) 

    return img,arr

# pts to arr
def pts2arr(points,newdim):
    # INT2FLOAT
    points = points.astype(float)
    #
    MAX = np.amax(points, axis=0)
    MIN = np.amin(points, axis=0)
    width = MAX.item(0) - MIN.item(0)
    height = MAX.item(1) - MIN.item(1)
    # RESIZE
    x_ratio = newdim / width
    y_ratio = newdim / height
    points *= [x_ratio,y_ratio]
    # FLOAT2INT
    points = np.ceil(points)
    points = points.astype(int)
    points[points == newdim] = newdim - 1
    # POINT2IMG
    arr = np.ones((newdim,newdim),np.int)
    arr[:] = -1
    for (x,y) in points:
	arr[x][y] = 1
    	
    return arr

def distance(pt1,pt2):
    return (pt1[0]-pt2[0])**2 + (pt1[1] - pt2[1])**2

def int2bytes(inp,size):
    out = []   # init
    for i in range(size):
        out.append(inp % 2)
        inp >>= 1
    out.reverse()	

    return np.array(out)
    
def bytes2int(bytes):
    result = 0
    for b in bytes:
        result = result * 2 + int(b)
    return result

#facial landmarks to 
def fpoints2feature(points, filename = None):
    features = []
    # width & height
    face_w = distance(points[0],points[16])
    face_h = distance(points[27],points[8])
    #eyebrow
    leyebrow_w = distance(points[17],points[21])	
    reyebrow_w = distance(points[22],points[26])
    #eye
    leye_w = distance(points[36],points[40])
    leye_h = distance(points[37],points[41]) + \
	     distance(points[38],points[40])
    reye_w = distance(points[42],points[45])
    reye_h = distance(points[43],points[47]) + \
	     distance(points[34],points[46])
    #mouse
    mouse_w = distance(points[49],points[53]) + \
	      distance(points[48],points[54]) + \
	      distance(points[59],points[55])  
    mouse_h = distance(points[50],points[58]) + \
	      distance(points[51],points[57]) + \
	      distance(points[52],points[56])
    mouse_h2 = distance(points[61],points[67]) + \
	       distance(points[62],points[66]) + \
	       distance(points[63],points[65])
    #normalize
    #ratio = 
      		
    return

#arr to points
def arr2pts(arr):
    xs = []
    ys = []
    count = 0
    if  len(arr.shape) == 1:
	dim = int(math.sqrt(len(arr)))
	arr = arr.reshape((dim,dim))
    for i in range(arr.shape[0]):
	for j in range(arr.shape[1]):
	    if  arr[i][j] == 1:
		xs.append(i)		
		ys.append(j)
		count += 1
    pts = np.zeros((count,2),np.int)
    for i in range(count):
	pts[i][0] = xs[i]
	pts[i][1] = ys[i]
    return pts	
	
#resize
def resizeDim(arr,newdim = 50,filename = None):
    pts = arr2pts(arr)
    return pts2arr(pts,newdim)
    
	

