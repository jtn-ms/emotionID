import numpy as np
import neurolab as nl
import config as cfg
import os
import os.path
import math
import util as utl

class RNN(object):
    def __init__(self, traindir='./train/', nettype='HopField'):
	self.traindir = traindir
	self.netname = 'rnn'
	self.netfilename = self.netname + '.net'
	self.nettype = nettype
	self.input_size = cfg.INPUT_SIZE#35#
	self.input_dim = cfg.DIM
	self.cls_cnt = cfg.CLASS_SIZE#2#
	if os.path.isfile(self.netfilename):
	   self.net = self.loadnet(self.netfilename)
	else:
	   self.net = self.train()
	   self.savenet(self.netfilename)

    #set train data
    def setTrainData4Test(self):
	#set in
	x = np.array(cfg.target)
	targets = x.reshape(self.cls_cnt,self.input_size)
	return targets

    def setTrainDataFromFile(self):	
	targets = np.empty((self.cls_cnt,self.input_size))
	# load	
	index = 0
	for filename in os.listdir(self.traindir):
    	    target=np.fromfile(self.traindir+filename,dtype=np.int)
	    # if size changed
	    if  len(target) != self.input_dim:
	    	target = utl.resizeDim(target,self.input_dim)
	    # endif
	    target=np.reshape(target,(self.input_size,))
	    targets[index,:] = target[:]
	    index += 1
	return targets
	
    #train	
    def train(self):
	print 'load targets'
	targets = self.setTrainDataFromFile()#self.setTrainData4Test()#
	print targets
	print 'rnn: training starts...'
	if self.nettype == 'HopField':
	   return nl.net.newhop(targets)
	else:
	   return nl.net.newhem(targets)
	print 'rnn: training finished...'
    #test
    def test(self,signal):
	return self.net.sim(signal)
    #load
    def loadnet(self,filename):
	print 'loading rnn from',filename
	return nl.load(filename)
    #save
    def savenet(self,filename):
	print 'saving rnn'
	self.net.save(filename)

'''
Reference
https://pythonhosted.org/neurolab/lib.html#module-neurolab.train
https://pythonhosted.org/neurolab/ex_newhop.html
https://pythonhosted.org/neurolab/ex_newhem.html
'''

