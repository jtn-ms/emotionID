import numpy as np
import neurolab as nl
import config as cfg
import os
import os.path
import math
import util as utl

class FNN(object):
    def __init__(self, traindir='./train/'):
	self.traindir = traindir
	self.netname = 'ffnn'
	self.netfilename = self.netname + '.net'
	self.input_size = cfg.INPUT_SIZE#35#
	self.input_dim = cfg.DIM
	self.cls_cnt = cfg.CLASS_SIZE#2#
	if os.path.isfile(self.netfilename):
	   self.net = self.loadnet(self.netfilename)
	else:
	   self.net = self.train()
	   self.savenet(self.netfilename)

    #set train data
    def setTrainData4Test(self):
	#set in
	x = np.array(cfg.target)
	inps = x.reshape(self.cls_cnt,self.input_size)
	#set out
	y = np.linspace(0.0, 1.0, num=self.cls_cnt)	
	outs = y.reshape(self.cls_cnt,1)
	return inps,outs

    def setTrainDataFromFile(self):
	#set in
	inps = np.empty((self.cls_cnt,self.input_size))
	index = 0
	for filename in os.listdir(self.traindir):
    	    inp=np.fromfile(self.traindir+filename,dtype=np.int)
	    # if size changed
	    if  len(inp) != self.input_dim:
	    	inp = utl.resizeDim(inp,self.input_dim)
	    print inp
	    # endif
	    inp=np.reshape(inp,(self.input_size,))
	    inps[index,:] = inp[:]
	    index += 1	
	#set out
	y = np.linspace(0.0, 1.0, num=self.cls_cnt)
	outs = y.reshape(self.cls_cnt,1)	
	return inps,outs

    #train	
    def initializeNet(self,nnlayout = [20,1]):
	#set min-max for input
	minmax = np.ones((self.input_size * 2,))
	minmax = minmax.reshape(self.input_size,2)
	for i in range(self.input_size):
    	    minmax[i][0] = -1
	#initialize net	
	return nl.net.newff(minmax,nnlayout)
	
    def train(self):
	# prepare training data
	inps,outs = self.setTrainDataFromFile()#self.setTrainData4Test()#
	# initialize net
	print 'ffnn: being initialized..'
	net = self.initializeNet()
	# train net
        print 'ffnn: training starts...'
	error = net.train(inps, outs, epochs=50, show=100, goal=0.001)
	print 'ffnn: training finished...'
	return net
	
    #test
    def test(self, signal):
	result = self.net.sim(signal)
	return result

    #set label
    def getLabel(self,filename):
	print 'on working'

    #load
    def loadnet(self,filename):
	print 'loading ffnn from',filename
	return nl.load(filename)

    #save
    def savenet(self,filename):
	print 'saving ffnn'
	self.net.save(filename)

'''
Reference
https://pythonhosted.org/neurolab/lib.html#module-neurolab.train
https://pythonhosted.org/neurolab/ex_newff.html
'''
