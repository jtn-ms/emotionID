import config as cfg
import rnn as rf
import ffnn as lgl
import util as utl
import numpy as np
import cv2

tgt_path = './train/T/'
test_cls_name = 'Positive'

n1 = rf.RNN(tgt_path)
n2 = lgl.FNN(tgt_path)
signal = np.fromfile('./train/' + test_cls_name +'/' + '0' + '.dat',dtype=np.int)
if  len(signal) != cfg.INPUT_SIZE:
    signal = utl.resizeDim(signal,cfg.DIM)
signal = signal.reshape((cfg.INPUT_SIZE,))
print signal
in2 = np.zeros((1,cfg.INPUT_SIZE),np.int)
in2[0,:] = signal[:]
refined = n1.test(in2)
print refined
print n2.test(refined)

cv2.imshow('in',utl.arr2img(signal[0]))
cv2.imshow('out',utl.arr2img(refined[0]))
cv2.waitKey(5000)
