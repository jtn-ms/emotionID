import os

#RGB ? GRAY
CHANNEL_SIZE = 1

# WebCam Config
IMAGE_SIZE = 39

# Facial LandMark
FACE_CASCADE_XML = './landmark/haarcascade_frontalface_alt.xml'
LANDMARK_SIZE = 68
LANDMARK_PREDICTOR = './landmark-68.dat'

# Questionaire
neutrals = [	'1+1=2?',
		'2+2=4?',
		'3+3=6',
		'4+4=8',
		'5+5=10',
		'6+6=12',
		'7+7=14',
		'8+8',
		'9+9=18',
		'10+10=20'
		]

postives = [	'Please remember the last time you laughed hard and happily.',
		'Please remember the last time you felt so good about yourself.',	
		'Please remember the last time you enjoyed great food.',
		'Please remember the best gift you ever received.',
		'Please remember the best place you visited as a tourist.',
		'Please remember the best movie you ever watched.',
		'Please remember the best time of your life.',
		'Please remember the biggest achievement of your life.',
		'Please remember the most enjoyable moment of your life.',
		'Please remember what you love about your best friend.'
		]

negatives = [	'Please remember the time you felt ill and sick',
		'Please remember the time when you heard the news that someone you love died.',
		'Please remember the time you cried with sadness.',
		'Please remember the time you felt very angry.',
		'Please remember the time you were extremely scared',
		'Please remember the time you were very very stressed',
		'Please remember the time you felt depressed and hopeless.',
		'Please remember the time you felt extremely bored.',
		'Please remember the biggest disappointment of your life.',
		'Please remember the worst thing ever happened to you'
		]

prefix1 = '>>>'
prefix2 = prefix1 + ' Q.'
instruction1 = 'TRAINING SESSION(PRESS SPACE TO START)'
instruction2 = 'PLEASE PRESS ENTER TO ANSWER THE QUESTION'
instruction2_1 = 'PLEASE PRESS ENTER TO PROCEED'
instruction3 = '(1)I REMEMBER  (2)I DONT REMEMBER'
instruction3_1 = '(T)FOR TRUE 	(F)FOR FALSE'


