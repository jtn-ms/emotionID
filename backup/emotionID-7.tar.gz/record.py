#import Tkinter as tk
import os
try:
    from Tkinter import *
except ImportError:
    from tkinter import *

import numpy as np
import cv2
import config as cfg

from PIL import Image, ImageTk

import caffe
from caffe.proto import caffe_pb2

from imutils.video import VideoStream
from imutils import face_utils
import imutils
import time
import dlib

#webcam + save video parameter
global cap
cap = cv2.VideoCapture(0)
global width,height
width, height = 640, 480
global fps
fps=20
global fourcc
fourcc = cv2.cv.CV_FOURCC('D','I','V','X')
global writer
writer = cv2.VideoWriter('record.AVI',	fourcc, fps, (width,height), 1)

#cascade
global face_cascade
face_cascade = cv2.CascadeClassifier(cfg.FACE_CASCADE_XML)

#dlib landmark
global detector
detector = dlib.get_frontal_face_detector()
global predictor
predictor = dlib.shape_predictor(cfg.LANDMARK_PREDICTOR)

#Maximize the Screen
class FullScreenApp(object):
    def __init__(self, master, **kwargs):
        self.master=master
        pad=3
        self._geom='200x200+0+0'
        master.geometry("{0}x{1}+0+0".format(
            master.winfo_screenwidth()-pad, master.winfo_screenheight()-pad))
        master.bind('<Escape>',self.toggle_geom)
	master.bind('<Escape>', lambda e: master.quit())

	self.master.bind('T',self.T_Pressed)
	self.master.bind('F',self.F_Pressed)
	self.master.bind('button-1',self.But1_Pressed)
	self.master.bind('button-2',self.But2_Pressed)
	self.master.bind("<space>", self.Space_Pressed)
	self.master.bind("<Return>",self.Enter_Pressed)
	
	#space between button and picture
	self.margin = Frame(self.master,width=100,height=100)
	self.margin.pack()
	#text label
	self.labelText = '>>> TRAINING SESSION(PRESS SPACE TO START)'
	self.question = Label(self.master, text = '')
	self.glabel = Label(self.master, text = self.labelText)
       	self.entry = Entry(self.master,text='Q & A',width=100)
	self.entry.focus()
	self.question.pack()
	self.instruction.pack()
	self.entry.pack()
	self.entry.pack_forget()
	#clear button
	self.clear_button = Button(self.master,text="Clear", command=self.clear_text)
	self.clear_button.pack(side=LEFT)

	#next button
	self.question_number = 0
	self.image_number = 0
	self.next_button = Button(self.master,text="Next", command=self.next_question)
	self.next_button.pack(side=RIGHT)
	###make dirs
	traindir = './out'
	if not os.path.exists(traindir):
	   os.makedirs(traindir)	
	dirname = './out/' + str(self.question_number)
	if not os.path.exists(dirname):
	   os.makedirs(dirname)

	#space between button and picture
	self.frame = Frame(self.master,width=100,height=50)
	self.frame.pack()
	#show input frame
        self.lmain = Label(self.master)
	self.lmain.pack()
	self.show_frame()

	#state info or temp 
	self.Img = np.zeros((height,width,3), np.uint8)
	self.Stages = ['Train','Test']
	self.Sessions = ['neutral','positive','negative']
	self.SessionStarted = False
	self.currentSession = self.Sessions[0]
	self.currentStage =  self.Stages[0]
     #######################################################################################
    #########################################################################################
     #######################################################################################
    def insert_text(self,question):
	self.clear_text()
	self.entry.insert(0,question)
	self.label.config(text=question)

    def clear_text(self):
  	self.entry.delete(0,'end')
	self.label['text'] = ''

    def next_question(self):
  	self.insert_text(questions[self.question_number])
	self.question_number += 1
	self.image_number = 0
	#make dir
	#os.mkdir('./out/' + str(self.question_number))
	dirname = './out/' + str(self.question_number)
	if not os.path.exists(dirname):
	   os.makedirs(dirname)
     #######################################################################################
    ###########################KEY EVENT HANDLE##############################################
     #######################################################################################
    def Space_Pressed(self,event):		
	print('SessionStart')

    def Enter_Pressed(self,event):
        """Took the current string the Entry Field."""
        response = self.entry.get()
        self.clear_text()
        print(response)
	#self.label.config(text=response)
	self.label['text'] = response
	return response

    def T_Pressed(self,event):
        """Took the current string the Entry Field."""
        response = self.entry.get()
        self.insert_text('True')    

    def F_Pressed(self,event):
        """Took the current string the Entry Field."""
        response = self.entry.get()
        self.insert_text('False')

    def But1_Pressed(self,event):
        """Took the current string the Entry Field."""
        response = self.entry.get()
        self.insert_text('False')

    def But2_Pressed(self,event):
        """Took the current string the Entry Field."""
        response = self.entry.get()
        self.insert_text('False')
     ###################################################################################
    ###########################FRAME HANDLE##############################################
     ###################################################################################        
    def show_frame(self):
	#ch = cv2.waitKey(1000 / fps)
	#if ch == 27:
	#   return
    	_, frame = cap.read()
    	frame = cv2.flip(frame, 1)
	frame = cv2.resize(frame, (width,height))
    		
	##save video
	writer.write(frame)
	##save image
	self.Img = frame
	#cv2.imwrite('./out/' + str(self.question_number) + '/' + str(self.image_number) +'.png',frame)
	#self.image_number += 1	
	#LandMark
	self.show_landmark(frame)
	#Red mark
	cv2.circle(frame, (width/2,height/4), 50, (0,0,255),3)
	cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)

    	img = Image.fromarray(cv2image)
    	imgtk = ImageTk.PhotoImage(image=img)
    	self.lmain.imgtk = imgtk
    	self.lmain.configure(image=imgtk)
    	self.lmain.after(10, self.show_frame)

    def detectFace(self,img):
	gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	faces = face_cascade.detectMultiScale(gray, 1.3, 5)		
	for (x,y,w,h) in faces:
    	    img = cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
	    break
	    #roi_gray = gray[y:y+h, x:x+w]
    	    #roi_color = img[y:y+h, x:x+w]
    	    #eyes = eye_cascade.detectMultiScale(roi_gray)
    	    #for (ex,ey,ew,eh) in eyes:
        	#cv2.rectangle(roi_color,(ex,ey),(ex+ew,ey+eh),(0,255,0),2)
	return faces

    def show_landmark(self,img):
	#
	frame = imutils.resize(img, width=400)
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

	# detect faces in the grayscale frame
	rects = detector(gray, 0)

	# calculate ratio
	x_ratio = float(width) / np.shape(gray)[1]
	y_ratio = float(height) / np.shape(gray)[0]

	# result
	shapes = np.zeros((np.shape(rects)[0]), dtype = np.int)

	# loop over the face detections
	for rect in rects:
	    # determine the facial landmarks for the face region, then
	    # convert the facial landmark (x, y)-coordinates to a NumPy
	    # array
	    shape = predictor(gray, rect)
	    shape = face_utils.shape_to_np(shape)

	    # loop over the (x, y)-coordinates for the facial landmarks
	    # and draw them on the image
  
	    i,pre_x,pre_y = 0,0,0	
	    for (x, y) in shape:	
		cv2.circle(img, (int(x_ratio * x), int(y_ratio * y)), 1, (0, 0, 255), -1)
	        if i > 0:
		   #cv2.line(img,(int(x_ratio * x), int(y_ratio * y)),(int(x_ratio * pre_x), int(y_ratio * pre_y)),(0,255,0),1)
		   pre_x,pre_y = x,y
		i += 1
	#return shape		

     #####################################################################################
    ###########################WINDOWS HANDLE##############################################
     #####################################################################################    
    def toggle_geom(self,event):
        geom=self.master.winfo_geometry()
        print(geom,self._geom)
        self.master.geometry(self._geom)
        self._geom=geom


def on_closing():
    if  messagebox.askokcancel("Quit", "Do you want to quit?"):
       	root.destroy()

if __name__ == '__main__':
    root = Tk()
    app = FullScreenApp(root)
    root.protocol("WM_DELETE_WINDOW", on_closing)
    root.mainloop()
